/**
 * cmsms_uisge-beatha
 * @version v1.0.0
 * @link https://github.com/UisgeBeatha436/cmsms_uisge-beatha
 * @author Gregor
 * @license GPL-3.0
 */
function googleTranslateElementInit(){new google.translate.TranslateElement({pageLanguage:"nl",includedLanguages:"en,fr,de,da,sv",layout:google.translate.TranslateElement.InlineLayout.SIMPLE,gaTrack:!0,gaId:"UA-3361592-1"},"google_translate_element")}!function(e,t,n){var a,o=e.getElementsByTagName(t)[0],s=/^http:/.test(e.location)?"http":"https";e.getElementById(n)||((a=e.createElement(t)).id=n,a.src=s+"://platform.twitter.com/widgets.js",o.parentNode.insertBefore(a,o))}(document,"script","twitter-wjs"),function(e,t,n){var a,o=e.getElementsByTagName(t)[0];e.getElementById(n)||((a=e.createElement(t)).id=n,a.async=!0,a.src="https://connect.facebook.net/nl_NL/sdk.js#xfbml=1&version=v3.2",o.parentNode.insertBefore(a,o))}(document,"script","facebook-jssdk"),window.fbAsyncInit=function(){FB.init({appId:"175931732519501",xfbml:!0,version:"v3.2"})},"function"==typeof facebookInit&&facebookInit(),function(e){var t=e.getElementsByTagName("SCRIPT")[0],n=e.createElement("SCRIPT");n.async=!0,n.src="https://assets.pinterest.com/js/pinit.js",t.parentNode.insertBefore(n,t)}(document);var googleTranslateScript=document.createElement("script");googleTranslateScript.async=!0,googleTranslateScript.src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit",(document.getElementsByTagName("head")[0]||document.getElementsByTagName("body")[0]).appendChild(googleTranslateScript);
//# sourceMappingURL=defer.js.map
