/**
 * cmsms_uisge-beatha
 * @version v1.0.0
 * @link https://github.com/UisgeBeatha436/cmsms_uisge-beatha
 * @author Gregor
 * @license GPL-3.0
 */
var rellax=new Rellax(".rellax",{callback:function(l){console.log(l)}});
//# sourceMappingURL=scripts.js.map
